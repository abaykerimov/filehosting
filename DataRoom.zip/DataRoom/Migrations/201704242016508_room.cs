namespace DataRoom.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class room : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Directories",
                c => new
                {
                    Id = c.Int(nullable: false, identity: true),
                    ParentId = c.Int(nullable: true),
                    Type = c.String(nullable: false),
                    Name = c.String(nullable: false),
                    Path = c.String(nullable: false),
                })
                .PrimaryKey(t => t.Id);
        }

    }
}
