﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataRoom.Models;
using IdentitySample.Models;
using System.IO;

namespace DataRoom.Controllers
{
    public class FilesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult GetParents()
        {
            return Json(db.Directories.Where(x => x.ParentId == null && x.Type == "Folder").ToList(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetChilds(int p)
        {
            return Json(db.Directories.Where(x => x.ParentId == p && x.Type == "Folder").ToList(), JsonRequestBehavior.AllowGet);
        }

        // GET: /Files/
        public ActionResult Index()
        {
            return View(db.Directories.Where(x => x.Type == "File").ToList());
        }

        // GET: /Files/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            var q = db.Directories.FirstOrDefault(x => x.Id == directories.ParentId);
            ViewBag.Folder = q.Name;
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // GET: /Files/Create
        public ActionResult Create()
        {
            //ViewBag.Name = new SelectList(db.Directories.Where(x => x.ParentId != null && x.Type == "Folder").ToList(), "Id", "Name");
            return View();
        }

        // POST: /Files/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(HttpPostedFileBase file, [Bind(Include = "ParentId")] Directories directories)
        {
            //ViewBag.DirList = new SelectList(db.Directories.Where(x => x.ParentId != null).ToList(), "Id", "Name");
            try
            {
                if (file.ContentLength > 0)
                {
                    directories.Path = @"C:/Users/abay-/Desktop/Test";
                    string _FileName = Path.GetFileName(file.FileName);
                    if (directories.ParentId == null)
                    {
                        string _path = Path.Combine(directories.Path, _FileName);
                        file.SaveAs(_path);
                    }
                    else
                    {
                        var p = db.Directories.FirstOrDefault(x => x.Id == directories.ParentId);
                        string name = p.Name;
                        string parent = p.Path;
                        string _path = Path.GetFullPath(Path.Combine(parent, _FileName));
                        directories.Path = _path;
                        file.SaveAs(_path);
                    }
                    
                    directories.Type = "File";
                    directories.Name = Path.GetFileName(file.FileName);
                    db.Directories.Add(directories);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                
                return View(directories);
            }
            catch
            {
                ViewBag.Message = "Произошла ошибка!";
                return View(directories);
            }  
            
        }

        // GET: /Files/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // POST: /Files/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,ParentId,Type,Name,Path")] Directories directories)
        {
            if (ModelState.IsValid)
            {
                db.Entry(directories).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(directories);
        }

        // GET: /Files/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // POST: /Files/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Directories directories = db.Directories.Find(id);
            string path = directories.Path;
            if (System.IO.File.Exists(path))
            {
                string name = directories.Name;
                System.IO.File.Delete(path);
                db.Directories.Remove(directories);
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
