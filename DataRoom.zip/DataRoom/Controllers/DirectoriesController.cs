﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DataRoom.Models;
using IdentitySample.Models;
using System.IO;

namespace DataRoom.Controllers
{
    public class DirectoriesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Directories
        public ActionResult Index()
        {
            return View(db.Directories.Where(x => x.Type == "Folder").ToList());
        }

        public ActionResult Folder(int? id, int? child)
        {
            if (id == null)
            {
                return View(db.Directories.ToList());
            } else if (child == null) {
                return View(db.Directories.Where(x => x.ParentId == id).ToList());
            }

            return View(db.Directories.Where(x => x.ParentId == child).ToList());
        }

        // GET: Directories/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            var q = db.Directories.FirstOrDefault(x => x.Id == directories.ParentId && x.Type == "Folder");
            if (q != null)
            {
                ViewBag.T = "Родительская папка";
                ViewBag.Parent = q.Name;
                ViewBag.Child = "";
            }
            else
            {
                ViewBag.T = "Дочерние папки";
                var s = db.Directories.Where(x => x.ParentId == directories.Id && x.Type == "Folder").ToList();
                if (s != null)
                {
                    ViewBag.Child = s;
                }
                
            }
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // GET: Directories/Create
        public ActionResult Create()
        {
            ViewBag.Name = new SelectList(db.Directories.Where(x => x.ParentId == null && x.Type == "Folder").ToList(), "Id", "Name");
            return View();
        }

        // POST: Directories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ParentId,Type,Name,Path")] Directories directories)
        {
            if (ModelState.IsValid)
            {
                directories.Path = @"C:/Users/abay-/Desktop/Test";
                
                if (directories.ParentId == null)
                {
                    string path = directories.Path + "/" + directories.Name;
                    if (!(Directory.Exists(path)))
                    {
                        Directory.CreateDirectory(path);
                        TempData["Message"] = "Папка создана!";
                        directories.Path = path;
                        directories.Type = "Folder";
                        db.Directories.Add(directories);
                        db.SaveChanges();
                    }
                    else
                    {
                        TempData["Message"] = "Папка с таким именем уже существует!";
                    }
                }
                else
                {
                    var p = db.Directories.FirstOrDefault(x => x.Id == directories.ParentId);
                    string parent = p.Name;
                    string path = directories.Path + "/" + parent + "/" + directories.Name;
                    directories.Path = path;
                    if (!(Directory.Exists(path)))
                    {
                        Directory.CreateDirectory(path);
                        TempData["Message"] = "Папка создана!";
                        directories.Type = "Folder";
                        db.Directories.Add(directories);
                        db.SaveChanges();
                    }
                    else
                    {
                        TempData["Message"] = "Папка с таким именем уже существует!";
                    }
                    
                }
                
                return RedirectToAction("Index");

            }

            return View(directories);
        }

        // GET: Directories/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // POST: Directories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ParentId,Type,Name,Path")] Directories directories)
        {
            if (ModelState.IsValid)
            {
                db.Entry(directories).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(directories);
        }

        // GET: Directories/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Directories directories = db.Directories.Find(id);
            var q = db.Directories.FirstOrDefault(x => x.Id == directories.ParentId && x.Type == "Folder");
            if (q != null)
            {
                ViewBag.T = "Родительская папка";
                ViewBag.Parent = q.Name;
                ViewBag.Child = "";
            }
            else
            {
                ViewBag.T = "Дочерние папки";
                var s = db.Directories.Where(x => x.ParentId == directories.Id && x.Type == "Folder").ToList();
                if (s != null)
                {
                    ViewBag.Child = s;
                }

            }
            if (directories == null)
            {
                return HttpNotFound();
            }
            return View(directories);
        }

        // POST: Directories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Directories directories = db.Directories.Find(id);
            string path = directories.Path;
            if (Directory.Exists(path))
            {
                if (Directory.GetFiles(path).Length != 0)
                {
                    TempData["Message"] = "Удалите сперва файлы в этой папке!";
                }
                else
                {
                    Directory.Delete(path);
                }
                
                if (!Directory.Exists(path))
                {
                    db.Directories.Remove(directories);
                    db.SaveChanges();
                }
            }
            
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
