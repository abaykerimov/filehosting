﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataRoom.Models
{
    public class Directories
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
    }
}